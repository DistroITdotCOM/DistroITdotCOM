FULL DOCUMENTATION HERE:
http://www.ajaxcrud.com/api/

Any questions or issues? -- support forum and reference material featured on the website www.ajaxcrud.com


USING THESE EXAMPLE SCRIPTS:

1) To install this class you must first manually CREATE a database. This is done (locally) by going
   into your mySQL terminal window and using the SQL "CREATE DATABASE [database_name]".

   If you are using an online host, you'll have to go into its control panel (eg C-panel) and create a database.

2) Make sure a database user has complete access to the database in question (SELECT, UPDATE, CREATE, DELETE)

3) Edit the file "preheader.php" and fill in your database information

4) Navigate to the file "/examples/install.php"

5) Navigate to the file "/examples/example.php" to test out the class!!





~Loud Canvas Media Staff
www.loudcanvas.com


NB: Make sure you include any "header" info (e.g. any HTML, echo statement,s etc) AFTER you 
include the ajaxCRUD class. 