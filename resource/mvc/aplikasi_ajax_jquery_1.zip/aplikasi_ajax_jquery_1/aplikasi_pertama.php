<html>
<head>
<title>Pemrograman JQuery</title>
<script type="text/javascript" src="jquery-1.4.2.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("div.content").append("Halo, apa kabar").css("color", "red");
});
</script>
</head>
<body>
<div class="content"></div>
</body>
</html>