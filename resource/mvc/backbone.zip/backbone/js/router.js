var AppRouter = Backbone.Router.extend({
    routes: {
    	
    	'': 'home',
    	'index.html': 'home',
        ':level': 'blockGrid', 
        'block/:level/:num': 'blockNum', 
        '*actions': 'defaultAction'       	
    },
    home : function()
    {
    	//Nothing Doing
    },
	blockGrid : function(level){
		grid(level);
 	},
	blockNum: function(level,num){
		gridNum(level,num);
 	},
   
});