This is the code for a Backbone.JS example at
http://bardevblog.wordpress.com/2012/01/16/understanding-backbone-js-simple-example/